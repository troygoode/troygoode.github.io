﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace YourMvcWebsite.Controllers
{
	public class SecurityController : Controller
	{

		[ControllerAction]
		public void Login()
		{
			RenderView("Login");
		}

		[ControllerAction]
		public void Register()
		{
			RenderView( "Register" );
		}

		[ControllerAction]
		public void Logout()
		{
			FormsAuthentication.SignOut();
			Response.Redirect( "/" );
		}

		[ControllerAction]
		public void Authenticate( string userName, string password, string rememberMe, string returnUrl )
		{
			// figure out if username and password are correct
			if( Membership.ValidateUser( userName, password ) )
			{
				// everything is good, create an authticket and go
				FormsAuthentication.SetAuthCookie( userName, (rememberMe != null) );
				Response.Redirect( returnUrl );
			}
			else
			{
				// something was wrong, figure out which and pass it into view
				if( Membership.GetUser(userName) == null )
					ViewData["ErrorMessage"] = "Incorrect username.";
				else
					ViewData["ErrorMessage"] = "Incorrect password.";
				RenderView( "Login" );
			}
		}

		[ControllerAction]
		public void CreateUser( string userName, string emailAddress, string password, string returnUrl )
		{
			try
			{
				// try to create user and then login that user
				if( Membership.CreateUser( userName, password, emailAddress ) == null )
					throw new MembershipCreateUserException( "An unspecified error occurred." );
				FormsAuthentication.SetAuthCookie( userName, true );
				Response.Redirect( returnUrl );
			}
			catch( MembershipCreateUserException e )
			{
				// something went wrong, pass the message down to the view
				ViewData["ErrorMessage"] = e.Message;
				RenderView("Register");
				return;
			}
		}

	}
}
