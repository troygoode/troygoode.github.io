﻿using EverlandStatePattern.TurnContexts;

namespace EverlandStatePattern.UnitCommands
{
	public class AttackCommand : IUnitCommand
	{
		private readonly AttackContext _attackContext;

		public AttackCommand(AttackContext attackContext)
		{
			_attackContext = attackContext;
		}

		#region IUnitCommand Members

		public void Execute()
		{
			_attackContext.Defender.Health -= 10;
		}

		#endregion
	}
}