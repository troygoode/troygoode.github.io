﻿namespace EverlandStatePattern.UnitCommands
{
	public class NullCommand : IUnitCommand
	{
		#region IUnitCommand Members

		public void Execute()
		{
		}

		#endregion
	}
}