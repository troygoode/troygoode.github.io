﻿using EverlandStatePattern.TurnContexts;

namespace EverlandStatePattern.UnitCommands
{
	public class MovementCommand : IUnitCommand
	{
		private readonly MovementContext _movementContext;

		public MovementCommand(MovementContext movementContext)
		{
			_movementContext = movementContext;
		}

		#region IUnitCommand Members

		public void Execute()
		{
			_movementContext.UnitToMove.Location = _movementContext.HexToMoveTo;
		}

		#endregion
	}
}