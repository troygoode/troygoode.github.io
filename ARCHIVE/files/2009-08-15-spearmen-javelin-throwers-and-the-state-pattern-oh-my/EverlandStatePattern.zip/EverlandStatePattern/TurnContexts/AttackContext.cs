﻿namespace EverlandStatePattern.TurnContexts
{
	public class AttackContext : ITurnContext
	{
		public Unit Attacker { get; set; }
		public Unit Defender { get; set; }
	}
}