﻿namespace EverlandStatePattern.TurnContexts
{
	public class MovementContext : ITurnContext
	{
		public Unit UnitToMove { get; set; }
		public Hex HexToMoveTo { get; set; }
	}
}