﻿using EverlandStatePattern.TurnContexts;
using EverlandStatePattern.UnitCommands;

namespace EverlandStatePattern.UnitStates
{
	public class JavelinThrower : UnitState
	{
		public IUnitCommand Handle(AttackContext context)
		{
			if (context.Attacker.Location.DistanceTo(context.Defender.Location) <= 2)
				return new AttackCommand(context);
			return new MovementCommand(new MovementContext
			                           	{
			                           		UnitToMove = context.Attacker,
			                           		HexToMoveTo =
			                           			context.Attacker.Location.FindClosestSurroundingHexTo(context.Defender.Location)
			                           	});
		}
	}
}