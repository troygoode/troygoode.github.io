﻿namespace EverlandStatePattern
{
	public interface ITurnContext
	{
	}
}