﻿using System.Collections.Generic;
using System.Linq;

namespace EverlandStatePattern
{
	public class World
	{
		public IEnumerable<Hex> Hexes { get; set; }

		public Hex GetHex(int x, int y)
		{
			return Hexes.Where(hex => hex.X == x && hex.Y == y).SingleOrDefault();
		}
	}
}