﻿namespace EverlandStatePattern
{
	public interface IUnitCommand
	{
		void Execute();
	}
}