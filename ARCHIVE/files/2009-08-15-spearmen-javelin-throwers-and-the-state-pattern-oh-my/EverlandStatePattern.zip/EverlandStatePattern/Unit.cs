﻿namespace EverlandStatePattern
{
	public class Unit
	{
		public Hex Location { get; set; }
		public int Health { get; set; }
		public UnitState CurrentState { get; set; }

		public void ExecuteTurn(ITurnContext context)
		{
			CurrentState.Handle(context).Execute();
		}
	}
}