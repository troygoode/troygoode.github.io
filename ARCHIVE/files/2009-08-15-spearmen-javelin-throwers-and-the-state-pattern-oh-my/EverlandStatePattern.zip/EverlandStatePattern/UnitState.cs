﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using EverlandStatePattern.UnitCommands;

namespace EverlandStatePattern
{
	public abstract class UnitState
	{
		private static readonly Dictionary<Int64, MethodInfo> Dispatch = new Dictionary<Int64, MethodInfo>();

		static UnitState()
		{
			foreach (var t in Assembly.GetCallingAssembly().GetTypes().Where(t => t.IsSubclassOf(typeof (UnitState))))
				foreach (var mi in t.GetMethods().Where(mi => mi.Name == "Handle" && mi.GetParameters().Length > 0))
					Dispatch.Add(((Int64) t.GetHashCode() << 32) + mi.GetParameters()[0].ParameterType.GetHashCode(), mi);
		}

		public IUnitCommand Handle(ITurnContext context)
		{
			var hash = ((Int64) GetType().GetHashCode() << 32) + context.GetType().GetHashCode();
			return Dispatch.ContainsKey(hash)
			       	? Dispatch[hash].Invoke(this, new[] {context}) as IUnitCommand
			       	: new NullCommand();
		}
	}
}