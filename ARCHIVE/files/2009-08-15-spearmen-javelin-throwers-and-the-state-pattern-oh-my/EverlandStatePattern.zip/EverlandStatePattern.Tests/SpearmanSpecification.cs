﻿using EverlandStatePattern.TurnContexts;
using EverlandStatePattern.UnitStates;
using Xunit;

namespace EverlandStatePattern.Tests
{
	public class SpearmanSpecification : TwoUnitsContext
	{
		public SpearmanSpecification()
		{
			Attacker.CurrentState = new Spearman();
			Attacker.Location = World.GetHex(3, 5);
			Defender.CurrentState = new Spearman();
			Defender.Location = World.GetHex(7, 5);
		}

		[Fact]
		public void Spearman_moves_to_one_hex_away_and_attacks()
		{
			//starting point
			Assert.Equal(4, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn one - moves closer
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(3, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn two - moves closer
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(2, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn three - moves closer
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(1, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn four - attacks
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(1, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(90, Defender.Health);
		}
	}
}