﻿using EverlandStatePattern.TurnContexts;
using EverlandStatePattern.UnitStates;
using Xunit;

namespace EverlandStatePattern.Tests
{
	public class JavelinThrowerSpecification : TwoUnitsContext
	{
		public JavelinThrowerSpecification()
		{
			Attacker.CurrentState = new JavelinThrower();
			Attacker.Location = World.GetHex(3, 5);
			Defender.CurrentState = new Spearman();
			Defender.Location = World.GetHex(7, 5);
		}

		[Fact]
		public void JavelinThrower_moves_to_two_hexes_away_and_attacks()
		{
			//starting point
			Assert.Equal(4, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn one - moves closer
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(3, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn two - moves closer
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(2, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(100, Defender.Health);

			//turn three - attacks
			Attacker.ExecuteTurn(new AttackContext {Attacker = Attacker, Defender = Defender});
			Assert.Equal(2, Attacker.Location.DistanceTo(Defender.Location));
			Assert.Equal(90, Defender.Health);
		}
	}
}