﻿using System.Collections.Generic;

namespace EverlandStatePattern.Tests
{
	public abstract class TwoUnitsContext
	{
		protected TwoUnitsContext()
		{
			World = new World();
			var hexes = new List<Hex>();
			for (var row = 0; row < 10; row++)
				for (var col = 0; col < 10; col++)
					hexes.Add(new Hex {X = col, Y = row, World = World});
			World.Hexes = hexes;

			Attacker = new Unit
			           	{
			           		Health = 100,
			           		CurrentState = null
			           	};
			Defender = new Unit
			           	{
			           		Health = 100,
			           		CurrentState = null
			           	};
		}

		protected World World { get; set; }
		protected Unit Attacker { get; set; }
		protected Unit Defender { get; set; }
	}
}