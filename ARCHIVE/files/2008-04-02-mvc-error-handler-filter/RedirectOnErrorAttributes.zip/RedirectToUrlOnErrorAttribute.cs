﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace SquaredRoot.Mvc.Filters.ErrorHandling
{
	public class RedirectToUrlOnErrorAttribute : RedirectOnErrorAttribute
	{

		public string Url{ get; set; }

		protected override bool Validate( FilterExecutedContext filterContext )
		{

			//### the url property is always needed
			if( string.IsNullOrEmpty( Url ) || Url.Trim() == string.Empty )
				throw new ArgumentNullException( "RedirectToUrlOnErrorAttribute's Url property must have a value." );

			//### continue execution
			return true;

		}

		protected override void Redirect( FilterExecutedContext filterContext )
		{
			filterContext.ExceptionHandled = true;
			filterContext.HttpContext.Response.Redirect( Url, true );
		}

	}
}
