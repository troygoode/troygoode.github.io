﻿using System.Web.Mvc;
using Xunit;
using DevPocalypse.Website.Controllers;

namespace DevPocalypse.Website.Tests.Controllers
{
	public class HomeControllerFacts
	{
		public class Index
		{
			[Fact]
			public void ReturnsViewResultWithDefaultViewName()
			{
				// Arrange
				var controller = new HomeController();

				// Act
				var result = controller.Index();

				// Assert
				var viewResult = Assert.IsType<ViewResult>( result );
				Assert.Empty( viewResult.ViewName );
			}

			[Fact]
			public void SetsViewDataWithNoModel()
			{
				// Arrange
				var controller = new HomeController();

				// Act
				var result = (ViewResult)controller.Index();

				// Assert
				Assert.Equal( "Home Page", result.ViewData["Title"] );
				Assert.Equal( "Welcome to ASP.NET MVC!", result.ViewData["Message"] );
				Assert.Null( result.ViewData.Model );
			}
		}

		public class About
		{
			[Fact]
			public void ReturnsViewResultWithDefaultViewName()
			{
				// Arrange
				var controller = new HomeController();

				// Act
				var result = controller.About();

				// Assert
				var viewResult = Assert.IsType<ViewResult>( result );
				Assert.Empty( viewResult.ViewName );
			}

			[Fact]
			public void SetsViewDataWithNoModel()
			{
				// Arrange
				var controller = new HomeController();

				// Act
				var result = (ViewResult)controller.About();

				// Assert
				Assert.Equal( "About Page", result.ViewData["Title"] );
				Assert.Null( result.ViewData.Model );
			}
		}
	}
}