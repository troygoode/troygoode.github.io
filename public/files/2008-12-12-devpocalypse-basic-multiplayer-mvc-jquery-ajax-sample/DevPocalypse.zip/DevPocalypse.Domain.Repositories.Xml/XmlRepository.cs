﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using DevPocalypse.Domain.Repositories.InMemory;

namespace DevPocalypse.Domain.Repositories.Xml
{
	public abstract class XmlRepository<T> : InMemoryRepository<T> where T : IIdentifiable
	{
		private readonly string key;

		protected XmlRepository()
		{
			key = string.Format( "XmlRepository.Storage[{0}]", typeof( T ).Name );
		}

		protected override IList<T> Load()
		{
			// load xml
			var filename = HttpContext.Current.Server.MapPath( VirtualPathUtility.ToAbsolute( string.Format( "~/App_Data/{0}.xml", key ) ) );
			if( !File.Exists( filename ) )
				return new List<T>();

			// deserialize
			using(var xmlReader = XmlReader.Create( filename ))
			{
				var serializer = new XmlSerializer( typeof(List<T>) );
				return (IList<T>)serializer.Deserialize( xmlReader );
			}
		}

		protected override void Persist()
		{
			// serialize to xml
			var serializer = new XmlSerializer( typeof(List<T>) );
			var xml = new StringBuilder();
			using(var sw = new StringWriter( xml ))
				serializer.Serialize( sw, data );

			// save xml
			var filename = HttpContext.Current.Server.MapPath( VirtualPathUtility.ToAbsolute( string.Format( "~/App_Data/{0}.xml", key ) ) );
			var xdoc = XDocument.Parse( xml.ToString() );
			xdoc.Save( filename );
		}
	}
}