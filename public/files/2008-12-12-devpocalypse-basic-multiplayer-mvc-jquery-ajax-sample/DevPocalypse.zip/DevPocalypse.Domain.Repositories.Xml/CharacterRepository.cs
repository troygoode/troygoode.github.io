﻿namespace DevPocalypse.Domain.Repositories.Xml
{
	public class CharacterRepository : XmlRepository<Character>, ICharacterRepository {}
}