﻿namespace DevPocalypse.Domain.Repositories.Xml
{
	public class ScreenRepository : XmlRepository<Screen>, IScreenRepository {}
}