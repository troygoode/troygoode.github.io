﻿using System;

namespace DevPocalypse.Domain
{
	public class Character : IIdentifiable
	{
		public Guid PlayerID { get; set; }
		public int Health { get; set; }
		public int HealthMax { get; set; }
		public int SpriteNumber { get; set; }
		public DateTime DateLastAction { get; set; }
		public Guid ScreenID { get; set; }
		public int X { get; set; }
		public int Y { get; set; }

		#region IIdentifiable Members

		public string Name { get; set; }

		public Guid ID { get; set; }

		#endregion
	}
}