﻿namespace DevPocalypse.Domain.Repositories
{
	public interface IScreenRepository : IRepository<Screen> {}
}