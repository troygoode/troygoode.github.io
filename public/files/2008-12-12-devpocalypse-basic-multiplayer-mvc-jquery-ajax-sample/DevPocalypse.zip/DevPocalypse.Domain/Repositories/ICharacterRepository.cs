﻿namespace DevPocalypse.Domain.Repositories
{
	public interface ICharacterRepository : IRepository<Character> {}
}