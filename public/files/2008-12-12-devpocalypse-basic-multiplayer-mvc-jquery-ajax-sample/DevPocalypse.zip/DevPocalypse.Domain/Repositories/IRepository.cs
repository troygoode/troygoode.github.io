﻿using System;
using System.Linq;

namespace DevPocalypse.Domain.Repositories
{
	public interface IRepository<T> where T : IIdentifiable
	{
		void Create( T t );
		IQueryable<T> Retrieve();
		T Retrieve( Guid id );
		void Update( T t );
		void Delete( T t );
	}
}