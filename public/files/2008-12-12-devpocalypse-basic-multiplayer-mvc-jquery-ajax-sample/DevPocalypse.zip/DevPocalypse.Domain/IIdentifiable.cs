﻿using System;

namespace DevPocalypse.Domain
{
	public interface IIdentifiable
	{
		Guid ID { get; set; }
		string Name { get; set; }
	}
}