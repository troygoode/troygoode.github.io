﻿using System;

namespace DevPocalypse.Domain
{
	public class Screen : IIdentifiable
	{
		public int Width { get; set; }
		public int Height { get; set; }

		#region IIdentifiable Members

		public string Name { get; set; }

		public Guid ID { get; set; }

		#endregion
	}
}