﻿using System;
using System.Linq;
using System.Web.Mvc;
using DevPocalypse.Domain;
using DevPocalypse.Domain.Repositories;
using DevPocalypse.Website.App.ModelBinders;

namespace DevPocalypse.Website.Controllers
{
	[Authorize]
	public class GameController : Controller
	{
		public ICharacterRepository CharacterRepository { get; set; }
		public IScreenRepository ScreenRepository { get; set; }

		public ViewResult Index()
		{
			ViewData["Title"] = "Play!";
			return View();
		}

		public JsonResult GetCurrentScreen(
			[ModelBinder( typeof( CurrentCharacterBinder ) )]
			Character currentCharacter
			)
		{
			// IE will cache aggressively if we don't set our expiration date
			Response.ExpiresAbsolute = DateTime.Now.AddYears( -1 );

			// get screen character is on, and a list of all characters on that screen
			var screen = ScreenRepository.Retrieve().Where( s => s.ID == currentCharacter.ScreenID ).Single();
			var characters = CharacterRepository.Retrieve().Where( c => c.ScreenID == screen.ID ).ToList();
			return Json( new { Screen = screen, MyCharacter = currentCharacter, Characters = characters } );			
		}

		public void MoveTo(
			[ModelBinder( typeof( CurrentCharacterBinder ) )]
			Character currentCharacter,
			int x,
			int y
			)
		{
			currentCharacter.X = x;
			currentCharacter.Y = y;
			CharacterRepository.Update( currentCharacter );
		}
	}
}