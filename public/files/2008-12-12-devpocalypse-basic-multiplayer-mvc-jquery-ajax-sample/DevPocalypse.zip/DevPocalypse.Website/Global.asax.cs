﻿using System;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Autofac.Builder;
using Autofac.Integration.Web;
using Autofac.Integration.Web.Mvc;
using DevPocalypse.Domain;
using DevPocalypse.Domain.Repositories;
using DevPocalypse.Website.App.DependencyInjection;

namespace DevPocalypse.Website
{
	public class MvcApplication : HttpApplication, IContainerProviderAccessor
	{
		private static IContainerProvider _containerProvider;

		#region IContainerProviderAccessor Members

		public IContainerProvider ContainerProvider { get { return _containerProvider; } }

		#endregion

		public static void RegisterRoutes( RouteCollection routes )
		{
			routes.IgnoreRoute( "{resource}.axd/{*pathInfo}" );
			routes.MapRoute(
				"Default", // Route name
				"{controller}/{action}/{id}", // URL with parameters
				new{ controller = "Home", action = "Index", id = "" } // Parameter defaults
				);
		}

		protected void Application_Start()
		{
			// register dependencies
			var builder = new ContainerBuilder();
			builder.RegisterModule( new PropertyInjectionForAllComponentsModule() );
			builder.RegisterModule( new AutofacControllerModule( Assembly.GetExecutingAssembly() ) );
			builder.Register<DevPocalypse.Domain.Repositories.Xml.CharacterRepository>().As<ICharacterRepository>();
			builder.Register<DevPocalypse.Domain.Repositories.Xml.ScreenRepository>().As<IScreenRepository>();
			_containerProvider = new ContainerProvider( builder.Build() );

			// use autofac controller factory for depency injection
			ControllerBuilder.Current.SetControllerFactory( new AutofacControllerFactory( _containerProvider ) );

			RegisterRoutes( RouteTable.Routes );

			// setup screen data
			//ToDo: switch this out for actual data connectivity
			var screenRepo = ContainerProvider.ApplicationContainer.Resolve<IScreenRepository>();
			screenRepo.Create( new Screen{
			                             	ID = Guid.NewGuid(),
			                             	Name = "CodeCamp",
			                             	Width = 12,
			                             	Height = 6
			                             } );
		}
	}
}