﻿using System.Web.Security;

namespace DevPocalypse.Website.App.XmlMembership
{
	public class FormsAuthenticationWrapper : IFormsAuthentication
	{
		#region IFormsAuthentication Members

		public void SetAuthCookie( string userName, bool createPersistentCookie )
		{
			FormsAuthentication.SetAuthCookie( userName, createPersistentCookie );
		}

		public void SignOut()
		{
			FormsAuthentication.SignOut();
		}

		#endregion
	}
}