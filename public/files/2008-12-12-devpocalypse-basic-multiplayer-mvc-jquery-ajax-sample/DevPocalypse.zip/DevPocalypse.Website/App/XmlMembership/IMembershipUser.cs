﻿using System;

namespace DevPocalypse.Website.App.XmlMembership
{
	public interface IMembershipUser
	{
		Guid ProviderUserKey { get; }
		string UserName { get; }
	}
}