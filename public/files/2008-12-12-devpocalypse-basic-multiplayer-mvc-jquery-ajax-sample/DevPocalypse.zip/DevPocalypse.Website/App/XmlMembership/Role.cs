﻿using System.Collections.Generic;

namespace DevPocalypse.Website.App.XmlMembership
{
	public class Role
	{
		private List<string> _UserNames;

		/// <summary>
		/// Initializes a new instance of the <see cref="Role"/> class.
		/// </summary>
		/// <param name="name">A name.</param>
		public Role( string name )
		{
			Name = name;
			_UserNames = new List<string>();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Role"/> class.
		/// </summary>
		public Role()
		{
			_UserNames = new List<string>();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Role"/> class.
		/// </summary>
		/// <param name="name">A name.</param>
		/// <param name="userNames">A list of users in role.</param>
		public Role( string name, List<string> userNames )
		{
			Name = name;
			_UserNames = userNames;
		}

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name { get; set; }

		/// <summary>
		/// Gets the users.
		/// </summary>
		/// <value>The users.</value>
		public List<string> Users
		{
			get { return _UserNames; }
			//set { _UserNames = value; }
		}
	}
}