﻿using System;
using System.Web.Security;
using DevPocalypse.Website.App.XmlMembership;

namespace DevPocalypse.Website.App.XmlMembership
{
	public class MembershipUserWrapper : IMembershipUser
	{
		private readonly MembershipUser MembershipUser;

		public MembershipUserWrapper()
		{
			MembershipUser = System.Web.Security.Membership.GetUser();
		}

		public MembershipUserWrapper( MembershipUser membershipUser )
		{
			MembershipUser = membershipUser;
		}

		#region IMembershipUser Members

		public Guid ProviderUserKey
		{
			get
			{
				return
					MembershipUser == null
						? Guid.Empty
						: (Guid) MembershipUser.ProviderUserKey;
			}
		}

		public string UserName
		{
			get
			{
				return
					MembershipUser == null
						? null
						: MembershipUser.UserName;
			}
		}

		#endregion
	}
}