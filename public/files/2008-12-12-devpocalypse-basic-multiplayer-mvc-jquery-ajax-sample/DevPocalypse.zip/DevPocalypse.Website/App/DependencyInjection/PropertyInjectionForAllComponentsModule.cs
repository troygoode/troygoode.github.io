﻿using Autofac;
using Autofac.Builder;

namespace DevPocalypse.Website.App.DependencyInjection
{
	public class PropertyInjectionForAllComponentsModule : Module
	{
		protected override void AttachToComponentRegistration( IContainer container, IComponentRegistration registration )
		{
			registration.Activating += ActivatingHandler.InjectProperties;
		}
	}
}