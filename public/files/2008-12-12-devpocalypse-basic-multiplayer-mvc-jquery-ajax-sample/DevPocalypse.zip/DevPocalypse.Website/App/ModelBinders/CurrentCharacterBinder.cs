﻿using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using DevPocalypse.Domain.Repositories;

namespace DevPocalypse.Website.App.ModelBinders
{
	public class CurrentCharacterBinder : IModelBinder
	{
		public ICharacterRepository CharacterRepository { get; set; }

		public CurrentCharacterBinder()
		{
			CharacterRepository = new DevPocalypse.Domain.Repositories.Xml.CharacterRepository();
		}

		#region IModelBinder Members

		public ModelBinderResult BindModel( ModelBindingContext bindingContext )
		{
			// get current user, and current user's character
			var user = Membership.GetUser();
			var userID = (Guid)user.ProviderUserKey;
			var character = CharacterRepository.Retrieve().Where( c=> c.PlayerID == userID ).SingleOrDefault();

			return new ModelBinderResult( character );
		}

		#endregion
	}
}