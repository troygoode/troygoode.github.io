﻿$(document).ready(function() {
	updateScreen();
	setInterval(updateScreen, updateFrequency * 1000);
});

var currentScreen = null;
var currentCharacter = null;
var currentCharacters = null;

function updateScreen() {
	$.get(url_updateScreenData, null, function(data) {

		// refresh currently drawn screen with new character positions
		updateCharacters( data.MyCharacter, data.Characters);

		// if we've navigated to a new screen, draw the new screen
		if (currentScreen == null || currentScreen.ID != data.Screen.ID)
			drawScreen(data.Screen);

		// make sure only the correct blocks are clickable for movement
		updateBlockClickability();

	}, "json");
}

function updateCharacters(myCharacter, allCharacters) {
	var oldCharacters = currentCharacters;
	currentCharacters = allCharacters;
	currentCharacter = myCharacter;

	// get character container
	var container = document.getElementById(id_characters);

	// loop through already placed characters and remove them if they are no longer on this screen
	if( oldCharacters != null )
		for (var oc = 0; oc < oldCharacters.length; oc++) {
			var isStillPresent = false;
			for (var cc = 0; cc < currentCharacters.length; cc++) {
				if (currentCharacters[cc].ID == oldCharacters[oc].ID) {
					isStillPresent = true;
					break;
				}
			}
			if (isStillPresent)
				continue;
			else
				container.removeChild(document.getElementById("#character_" + oldCharacters[oc].Name));
		}

	// loop through current characters and if they aren't already placed, create them
	for (var cc = 0; cc < currentCharacters.length; cc++) {
		var isAlreadyPresent = false;
		if( oldCharacters != null )
			for (var oc = 0; oc < oldCharacters.length; oc++) {
				if (currentCharacters[cc].ID == oldCharacters[oc].ID) {
					isAlreadyPresent = true;
					break;
				}
			}
		if (isAlreadyPresent)
			continue;
		else {
			var id = "character_" + currentCharacters[cc].Name;
			var div = document.createElement("div");
			div.setAttribute("id", id);
			div.setAttribute("class", "character character-new");
			div.setAttribute("style", "display:none");
			container.appendChild(div);
			$("#" + id).css("background-image", "url(/Content/Sprites/Sprite" + currentCharacters[cc].SpriteNumber + ".png)");
		}
	}

	// position each character
	for (var c = 0; c < currentCharacters.length; c++) {
		var id = "character_" + currentCharacters[c].Name;
		if (!$("#" + id).hasClass("character-new"))
			$("#" + id).animate({
				left: currentCharacters[c].X * 33,
				top: currentCharacters[c].Y * 33
			}, updateFrequency * 1000 / 4);
		else
			$("#" + id)
				.css("left", currentCharacters[c].X * 33)
				.css("top", currentCharacters[c].Y * 33)
				.removeClass("character-new")
				.fadeIn(updateFrequency * 1000);
	}
}

function drawScreen(newScreen) {
	currentScreen = newScreen;

	// get board
	var screen = document.getElementById(id_screen);

	// remove current blocks
	for (var b = 0; b < screen.childNodes.length; b++)
		screen.removeChild(screen.childNodes[b]);

	// create new blocks
	for (var y = 0; y < currentScreen.Height; y++) {
		for (var x = 0; x < currentScreen.Width; x++) {
			var div = document.createElement("div");
			div.setAttribute("id", "block_" + x + "_" + y);
			if (y == 0 && x == 0)
				div.setAttribute("class", "block block-left block-top");
			else if (y == 0)
				div.setAttribute("class", "block block-top");
			else if (x == 0)
				div.setAttribute("class", "block block-left");
			else
				div.setAttribute("class", "block");
			screen.appendChild(div);
		}
		var br = document.createElement("br");
		br.setAttribute("class", "clear-both");
		screen.appendChild(br);
	}
}

function updateBlockClickability() {
	// unbind click event handler from blocks
	$(".block-clickable").unbind("click");

	// update clickability of blocks
	$(".block").removeClass("block-clickable");
	$("#block_" + (currentCharacter.X + 1) + "_" + (currentCharacter.Y + 0)).addClass("block-clickable"); // right
	$("#block_" + (currentCharacter.X - 1) + "_" + (currentCharacter.Y + 0)).addClass("block-clickable"); // left
	$("#block_" + (currentCharacter.X + 0) + "_" + (currentCharacter.Y + 1)).addClass("block-clickable"); // bottom
	$("#block_" + (currentCharacter.X + 0) + "_" + (currentCharacter.Y - 1)).addClass("block-clickable"); // top
	$("#block_" + (currentCharacter.X + 1) + "_" + (currentCharacter.Y + 1)).addClass("block-clickable"); // upper-right
	$("#block_" + (currentCharacter.X + 1) + "_" + (currentCharacter.Y - 1)).addClass("block-clickable"); // lower-right
	$("#block_" + (currentCharacter.X - 1) + "_" + (currentCharacter.Y + 1)).addClass("block-clickable"); // upper-left
	$("#block_" + (currentCharacter.X - 1) + "_" + (currentCharacter.Y - 1)).addClass("block-clickable"); // lower-left

	// bind new event handler
	$(".block-clickable").click(function() {
		// parse x,y coords
		var id = this.id.substring(this.id.indexOf('_') + 1);
		var x = id.substring(0, id.indexOf('_'));
		var y = id.substring(id.indexOf('_') + 1);

		// move character
		$.post(url_moveTo, { x: x, y: y }, function(data) {
			updateScreen();
		}, "json");
	});
}