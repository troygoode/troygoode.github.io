﻿namespace DevPocalypse.Domain.Repositories.InMemory
{
	public class ScreenRepository : InMemoryRepository<Screen>, IScreenRepository {}
}