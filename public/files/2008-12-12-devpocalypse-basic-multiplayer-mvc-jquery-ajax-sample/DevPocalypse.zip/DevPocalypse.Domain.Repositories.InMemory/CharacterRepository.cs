﻿namespace DevPocalypse.Domain.Repositories.InMemory
{
	public class CharacterRepository : InMemoryRepository<Character>, ICharacterRepository {}
}