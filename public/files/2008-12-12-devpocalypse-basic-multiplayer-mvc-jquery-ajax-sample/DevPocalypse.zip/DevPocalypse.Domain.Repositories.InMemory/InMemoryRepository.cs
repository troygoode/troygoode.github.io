﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevPocalypse.Domain.Repositories.InMemory
{
	public abstract class InMemoryRepository<T> : IRepository<T> where T : IIdentifiable
	{
		private readonly string key;
		protected IList<T> data;

		protected InMemoryRepository()
		{
			key = string.Format( "InMemoryRepository.Cache[{0}]", typeof(T).Name );
		}

		#region IRepository<T> Members

		public void Create( T t )
		{
			if( data == null )
				data = Load();
			lock(data)
			{
				data.Add( t );
				Persist();
			}
		}

		public IQueryable<T> Retrieve()
		{
			if( data == null )
				data = Load();
			return data.AsQueryable();
		}

		public T Retrieve( Guid id )
		{
			if( data == null )
				data = Load();
			return data.AsQueryable().Where( t => t.ID == id ).SingleOrDefault();
		}

		public void Update( T t )
		{
			if( data == null )
				data = Load();
			lock(data)
			{
				Delete( Retrieve( t.ID ) );
				Create( t );
				Persist();
			}
		}

		public void Delete( T t )
		{
			if( data == null )
				data = Load();
			lock(data)
			{
				data.Remove( t );
				Persist();
			}
		}

		#endregion

		protected virtual IList<T> Load()
		{
			return (IList<T>)HttpContext.Current.Cache[key] ?? new List<T>();
		}

		protected virtual void Persist()
		{
			HttpContext.Current.Cache[key] = data;
		}
	}
}